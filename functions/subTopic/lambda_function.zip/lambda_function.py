import requests, os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import messaging

cred = credentials.Certificate("credentials/serviceAccountKey.json")
firebase_admin.initialize_app(cred)


def lambda_handler(event, context):
    date = event["queryStringParameters"]["date"]
    time = event["queryStringParameters"]["time"]
    device_token = event["queryStringParameters"]["device_token"]
    #bool. to subscribe or not
    subscribe = event["queryStringParameters"]["subscribe"]

    return subscribe_to_topic(os.environ.get("ATLAS_URI"), date, time, subscribe, device_token)


def subscribe_to_topic(host, date, time, subscribe, device_token):
    response = ""
    date = date.replace("-", "")
    time = time.replace(":", "")
    if subscribe == "true":
        response = messaging.subscribe_to_topic([device_token], date + time)
    else:
        response = messaging.unsubscribe_from_topic([device_token], (date + time))

    return response